"""Markdown report builder with a release-style quality gate."""
from __future__ import annotations

from datetime import date

from .common import Issue, count_by_severity

RECOMMENDATIONS = {
    "invalid_label": "Enforce a closed label set in the annotation tool (dropdown, not free text) and add schema validation on export.",
    "empty_text": "Filter empty / whitespace-only items in the ingestion pipeline before they reach annotators.",
    "duplicate_text": "Deduplicate on normalized text before labeling and before train/test splitting to avoid leakage.",
    "missing_annotation": "Re-queue items that are missing an annotator's label until coverage is complete.",
    "low_overall_agreement": "Hold a calibration session, tighten the guidelines for ambiguous classes, and re-measure kappa.",
    "low_annotator_agreement": "Review the outlier annotator's work against the guidelines; retrain or reassign before using their labels.",
    "low_gold_accuracy": "Pause the low-accuracy annotator, give feedback on missed gold items, and re-test on a fresh gold set.",
    "no_majority": "Send no-majority items to an expert adjudicator for the final label.",
    "position_bias": "Randomize A/B order per annotator and add a short refresher on ignoring position.",
    "length_bias": "Add 'do not reward length alone' to the preference rubric and include calibration pairs where the shorter answer is better.",
    "invalid_preference_row": "Validate preference exports (choice in A/B/tie) before aggregation.",
    "low_preference_agreement": "Clarify the preference rubric (helpfulness, accuracy, safety order of precedence) and recalibrate.",
    "no_consensus_pairs": "Collect an additional vote or expert adjudication for pairs without a majority.",
}


def _table(headers, rows):
    out = ["| " + " | ".join(headers) + " |", "|" + "|".join("---" for _ in headers) + "|"]
    for r in rows:
        out.append("| " + " | ".join(str(c).replace("|", "\\|") for c in r) + " |")
    return "\n".join(out)


def _examples(items, n=5):
    items = [str(i) for i in items]
    if not items:
        return ""
    return ", ".join(items[:n]) + (f" (+{len(items) - n} more)" if len(items) > n else "")


def _issue_table(issues):
    if not issues:
        return "_No issues found._"
    order = {"critical": 0, "major": 1, "minor": 2, "info": 3}
    rows = [(i.severity.upper(), i.check, i.message, _examples(i.items)) for i in sorted(issues, key=lambda x: order[x.severity])]
    return _table(["Severity", "Check", "Finding", "Examples"], rows)


def gate_status(issues: list[Issue]) -> str:
    c = count_by_severity(issues)
    if c["critical"] or c["major"]:
        return "FAIL"
    return "PASS WITH WARNINGS" if c["minor"] else "PASS"


def build_report(ds: dict, ov: dict, rl: dict) -> str:
    all_issues = ds["issues"] + rl["issues"]
    gate = gate_status(all_issues)
    sev = count_by_severity(all_issues)
    d, o, r = ds["summary"], ov["summary"], rl["summary"]
    sc = o["validator_self_check"]
    L = [f"# AI QA Evaluation Report", f"_Generated {date.today().isoformat()}_", "",
         f"## Quality gate: **{gate}**", "",
         _table(["Area", "Headline result"], [
             ("Dataset annotation QC", f"{d['n_items']} items / {d['n_rows']} annotations, Fleiss' kappa {d['fleiss_kappa']} ({d['fleiss_interpretation']}), {len(ds['issues'])} issue type(s)"),
             ("LLM output validation", f"{o['passed']}/{o['total']} outputs passed ({o['pass_rate']:.0%}); {o['failed']} failed"),
             ("RLHF preference data", f"{r['n_pairs']} pairs, Fleiss' kappa {r['fleiss_kappa']} ({r['fleiss_interpretation']}), {len(rl['issues'])} issue type(s)"),
         ]), "",
         f"Issues by severity: critical **{sev['critical']}**, major **{sev['major']}**, minor **{sev['minor']}**. "
         "Gate rule: any critical/major issue = FAIL; minor only = PASS WITH WARNINGS.", "",
         "---", "## 1. Dataset annotation QC", "",
         "**Label distribution:** " + ", ".join(f"{k} {v}" for k, v in sorted(d["label_distribution"].items())), "",
         "**Pairwise Cohen's kappa**", "",
         _table(["Pair", "Kappa", "Shared items"], [(p, v["kappa"], v["n"]) for p, v in d["pairwise_kappa"].items()]), "",
         "**Accuracy vs gold-standard items**", "",
         _table(["Annotator", "Correct", "Total", "Accuracy", "Mean kappa vs others"],
                [(a, g["correct"], g["total"], f"{g['accuracy']:.0%}", d["annotator_mean_kappa"].get(a, "n/a")) for a, g in d["gold_accuracy"].items()]), "",
         "**Findings**", "", _issue_table(ds["issues"]), "",
         "---", "## 2. LLM output validation", "",
         f"Pass rate: **{o['pass_rate']:.0%}** ({o['passed']}/{o['total']}). Failures by check: "
         + (", ".join(f"{k}: {v}" for k, v in sorted(o["failures_by_check"].items())) or "none"), "",
         _table(["Output", "Task", "Failed check", "Detail"],
                [(x["id"], x["task_type"], f["check"], f["detail"]) for x in ov["results"] for f in x["failures"]]), "",
         "**Validator self-check** (does the QA tool itself agree with human-labelled verdicts?)", "",
         _table(["Labeled records", "Precision", "Recall", "False negatives (missed bad outputs)", "False positives"],
                [(sc["labeled_records"], sc["precision"], sc["recall"], ", ".join(sc["false_negatives"]) or "none",
                  ", ".join(sc["false_positives"]) or "none")]), "",
         "> Rule-based checks cannot judge meaning. Any false negative above is a documented limitation that needs human review or an LLM-as-judge layer.", "",
         "---", "## 3. RLHF / human-feedback evaluation", "",
         _table(["Model", "Wins", "Decided pairs", "Win rate", "95% CI"],
                [(m, w["wins"], w["decided_pairs"], w["win_rate"], f"{w['ci95'][0]:.2f} to {w['ci95'][1]:.2f}") for m, w in r["win_rates"].items()]),
         f"\nTies: {r['tie_pairs']}, pairs without majority: {r['no_consensus_pairs']}.", "",
         _table(["Annotator", "Rows", "% chose A", "% chose longer", "Agrees w/ majority", "Flags"],
                [(a, s["n"], s["pct_choose_A"], s["pct_choose_longer"], s["agreement_with_majority"], ", ".join(s["flags"]) or "none")
                 for a, s in r["annotators_detail"].items()]), "",
         "**Findings**", "", _issue_table(rl["issues"]), "",
         "---", "## 4. Recommended actions", ""]
    seen = []
    for i in all_issues:
        if i.check in RECOMMENDATIONS and i.check not in seen:
            seen.append(i.check)
            L.append(f"- **{i.check}**: {RECOMMENDATIONS[i.check]}")
    return "\n".join(L) + "\n"
