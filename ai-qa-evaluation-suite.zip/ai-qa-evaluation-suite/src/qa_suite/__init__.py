"""AI QA Evaluation Suite: dataset QC, LLM output validation, RLHF preference evaluation."""
__version__ = "1.0.0"
