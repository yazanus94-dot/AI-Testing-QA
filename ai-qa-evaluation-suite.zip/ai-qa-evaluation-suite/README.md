# AI QA Evaluation Suite

A QA project for **AI/ML systems**: it plans, executes, and documents quality checks across three layers that matter when shipping an LLM product.

1. **LLM output validation:** is the model's answer well-formed, correct, safe, and free of private data?
2. **Dataset / annotation quality control:** are the human labels clean, consistent, and trustworthy?
3. **RLHF / human-feedback evaluation:** are preference judgments reliable, and is the new model actually winning?

Everything runs with the **Python standard library only**. A single command produces a quality-gate report.

```bash
python scripts/generate_sample_data.py   # (optional) regenerate the sample data
python run_qa.py                         # writes reports/qa_report.md and .json
python run_qa.py --fail-on-gate          # exit code 1 if the gate is FAIL (for CI/CD)
pip install pytest && pytest -q          # 28 tests
```

## How the project maps to the QA Engineer role

| Role requirement | Where it is demonstrated |
|---|---|
| Test planning | [`docs/test_plan.md`](docs/test_plan.md): scope, strategy, entry / exit criteria, severity model, risks |
| Test execution | [`run_qa.py`](run_qa.py) and 35 documented cases in [`docs/test_cases.csv`](docs/test_cases.csv) (most automated) |
| Documentation | Test plan, test cases, [bug reports](docs/bug_reports.md), generated [`reports/qa_report.md`](reports/qa_report.md) |
| AI/ML model evaluation and output validation | [`output_validation.py`](src/qa_suite/output_validation.py): JSON format, factual, refusal, prompt-injection, PII, length, repetition checks, plus **precision / recall of the validator itself** |
| Data labeling, annotation, dataset QC | [`dataset_qc.py`](src/qa_suite/dataset_qc.py) and [`annotation_guidelines.md`](docs/annotation_guidelines.md): schema, duplicates, completeness, Cohen's / Fleiss' kappa, gold-set accuracy, adjudication queue |
| RLHF / human-feedback evaluation | [`rlhf_eval.py`](src/qa_suite/rlhf_eval.py): majority-vote win rate with confidence intervals, inter-annotator agreement, **position-bias and verbosity-bias detection** |
| Cross-functional communication | Severity-ranked findings with evidence, impact, and suggested action; plain-language recommendations section in the report |

## Sample results (`reports/qa_report.md`)

The sample data contains **deliberately planted defects**. The suite blocks the release and explains why:

| Area | Result |
|---|---|
| Quality gate | **FAIL** (10 major, 3 minor issues) |
| Output validation | 10 / 21 outputs pass; catches hallucination, safety non-refusal, prompt-injection leak, PII leak, broken JSON, length violation, empty and repetitive output |
| Validator self-check | Precision 1.00, recall 0.92. Misses `out_021` (wrong date; keyword rules cannot see it), documented as a limitation |
| Label QC | Finds invalid labels, empty text, duplicate texts, missing annotations, low-agreement annotator, low gold accuracy (Fleiss' kappa 0.585, moderate) |
| RLHF QC | Finds invalid choices, `ann_2` position bias (83% choose A), `ann_3` verbosity bias (100% choose longer); Fleiss' kappa 0.233 (fair) |

## Project layout

```
ai-qa-evaluation-suite/
├── run_qa.py                    # CLI entry point and quality gate
├── src/qa_suite/
│   ├── dataset_qc.py            # annotation quality control
│   ├── output_validation.py     # LLM output oracles
│   ├── rlhf_eval.py             # preference-data evaluation
│   ├── metrics.py               # Cohen / Fleiss kappa, Wilson CI
│   ├── report.py                # Markdown report and gate logic
│   └── common.py
├── data/                        # sample JSONL (annotations, model outputs, preferences)
├── docs/                        # test plan, test cases, guidelines, bug reports
├── reports/                     # generated QA report
├── scripts/generate_sample_data.py
├── tests/                       # 28 pytest tests (unit + end-to-end)
└── .github/workflows/ci.yml     # runs tests and uploads the report
```

## Design decisions worth discussing

- **Constraints are data, not code.** Each model-output record carries its own expectations (`must_include`, `should_refuse`, `max_words`, ...), so QA can add test cases without touching the validator.
- **QA the QA tool.** The validator is scored against human-labelled verdicts; its false negatives are reported, not hidden.
- **Statistics with context.** Every metric reports its sample size; win rates carry a 95% Wilson interval; kappa is interpreted with Landis & Koch bands.
- **Bias checks are separate.** Position bias and verbosity bias are measured independently to avoid mistaking one for the other.
- **Fail loudly on bad input.** Corrupt lines and missing fields are reported as critical findings; the pipeline never crashes on dirty data.

## Using your own data

| File | One row per | Required fields |
|---|---|---|
| `annotations.jsonl` | annotation | `item_id`, `text`, `annotator`, `label` (optional `gold_label`) |
| `model_outputs.jsonl` | model output | `id`, `prompt`, `output`, `constraints` (optional `expected_verdict`) |
| `preferences.jsonl` | human judgment | `pair_id`, `prompt`, `response_a/b`, `source_a/b`, `annotator`, `choice` (`A`/`B`/`tie`) |

Thresholds (kappa, gold accuracy, bias bands) are function arguments in `src/qa_suite/` and are documented in the test plan.

## Possible next steps
LLM-as-judge layer for semantic checks (to close the `out_021` gap), a Krippendorff's alpha option for ordinal labels, per-class precision / recall against gold, and a small dashboard on top of `qa_report.json`.

---
*Data in this repository is synthetic and generated by `scripts/generate_sample_data.py`.*
